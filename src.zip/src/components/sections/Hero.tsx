import Container from '../ui/Container'
import Button from '../ui/Button'
import logoFull from '../../assets/logo-full.png'

const stats = [
  { value: '3', label: 'sports, one heritage roof' },
  { value: '1', label: 'rice mill, given new purpose' },
  { value: 'Soon', label: 'opening in San Fernando City' },
]

export default function Hero() {
  return (
    <section id="home" className="relative isolate overflow-hidden bg-ink py-16 sm:py-24 lg:py-28">
      <div aria-hidden="true" className="pointer-events-none absolute -right-40 -top-56 h-[34rem] w-[34rem] rounded-full border border-citrus/15 sm:-right-24" />
      <div aria-hidden="true" className="pointer-events-none absolute -right-16 -top-28 h-[26rem] w-[26rem] rounded-full border border-sand/10" />
      <div aria-hidden="true" className="pointer-events-none absolute bottom-0 left-0 h-px w-2/3 bg-gradient-to-r from-citrus/50 to-transparent" />
      <Container className="relative grid items-center gap-14 lg:grid-cols-[1.08fr_0.92fr] lg:gap-16">
        <div className="flex flex-col items-start gap-7">
          <span className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-citrus px-4 py-1.5 text-xs font-bold uppercase tracking-[0.12em] text-ink">
              Coming Soon
            </span>
            <span className="rounded-full border border-sand/20 bg-sand/5 px-4 py-1.5 text-xs font-medium text-sand/75">
              San Fernando City, La Union
            </span>
          </span>

          <h1 className="max-w-3xl text-balance font-display text-4xl font-semibold leading-[0.99] text-sand sm:text-5xl lg:text-7xl">
            A place with a past, now creating a new story.
          </h1>

          <p className="max-w-xl text-balance text-sm leading-7 text-sand/70 sm:text-base sm:leading-8">
            A heritage warehouse that once served as a rice mill is being transformed into 2500
            Heritage — a home for Pickleball, Badminton &amp; Taekwondo where families, friends,
            athletes, and the community can play, train, connect, and create new memories.
          </p>

          <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
            <Button href="/booking" variant="primary">
              Reserve a Court
            </Button>
            <Button href="#story" variant="secondary">
              Read our story
            </Button>
          </div>

          <dl className="mt-3 grid w-full grid-cols-3 gap-4 border-t border-sand/10 pt-6 sm:gap-7">
            {stats.map((stat) => (
              <div key={stat.label} className="flex flex-col gap-1">
                <dt className="sr-only">{stat.label}</dt>
                <dd className="font-display text-xl font-semibold text-tide-light sm:text-2xl">
                  {stat.value}
                </dd>
                <dd className="max-w-32 text-[0.68rem] leading-snug text-sand/60 sm:text-xs">{stat.label}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="relative mx-auto w-full max-w-md lg:max-w-none">
          <div aria-hidden="true" className="absolute -inset-4 rotate-3 rounded-[2.5rem] border border-citrus/35" />
          <div className="relative overflow-hidden rounded-[2rem] border border-sand/50 bg-sand p-7 shadow-[0_32px_90px_rgba(0,0,0,0.38)] sm:p-10 lg:p-12">
            <img
              src={logoFull}
              alt="2500 Heritage — Pickleball, Badminton &amp; Taekwondo"
              className="w-full drop-shadow-sm"
            />
          </div>
          <div className="absolute -bottom-5 right-4 rounded-2xl border border-sand/10 bg-ink-soft px-4 py-3 shadow-xl sm:right-8">
            <p className="text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-citrus">Play. Train. Belong.</p>
            <p className="mt-1 text-xs text-sand/65">A new home for the community</p>
          </div>
        </div>
      </Container>
    </section>
  )
}
