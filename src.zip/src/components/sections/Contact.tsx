import { useState, type FormEvent, type ReactNode } from 'react'
import Container from '../ui/Container'
import SectionHeading from '../ui/SectionHeading'
import Button from '../ui/Button'

export default function Contact() {
  const [submitted, setSubmitted] = useState(false)

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setSubmitted(true)
  }

  return (
    <section id="contact" className="bg-sand-dim py-20 sm:py-28 lg:py-32">
      <Container className="grid gap-12 lg:grid-cols-[1fr_0.9fr] lg:items-start lg:gap-20">
        <div className="flex flex-col gap-9">
          <SectionHeading
            title="Get notified when we open"
            lede="Leave your details and we’ll reach out with construction updates and the official opening date — or follow us on social media for the latest."
          />

          <div className="flex flex-col gap-5">
            <div className="flex gap-4 rounded-2xl border border-ink/8 bg-sand p-4">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-court/10"><IconPin /></span>
              <div>
                <h3 className="text-sm font-semibold text-ink">Find us</h3>
                <p className="mt-1 text-sm text-ink/65">
                  1 Lucero St, cor. P. Burgos St, San Fernando City, La Union
                </p>
              </div>
            </div>
            <div className="flex gap-4 rounded-2xl border border-ink/8 bg-sand p-4">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-court/10"><IconClock /></span>
              <div>
                <h3 className="text-sm font-semibold text-ink">Status</h3>
                <p className="mt-1 text-sm text-ink/65">Under transformation — opening soon</p>
              </div>
            </div>
            <div className="flex gap-4 rounded-2xl border border-ink/8 bg-sand p-4">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-court/10"><IconPhone /></span>
              <div>
                <h3 className="text-sm font-semibold text-ink">Follow along</h3>
                <p className="mt-1 text-sm text-ink/65">Construction updates shared on our social pages</p>
              </div>
            </div>
          </div>

          <div className="overflow-hidden rounded-card border border-ink/10 shadow-xl shadow-ink/10">
            <iframe
              title="2500 Heritage location on Google Maps"
              src="https://www.google.com/maps?q=2500%20HERITAGE%2C%201%20Lucero%20St%2C%20Cor%20P.%20Burgos%20St%2C%20San%20Fernando%20City%2C%20La%20Union%2C%20Philippines&output=embed"
              className="h-[220px] w-full sm:h-[280px]"
              style={{ border: 0 }}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>

        <div className="rounded-card border border-ink/10 bg-sand p-6 shadow-xl shadow-ink/5 sm:p-9">
          {submitted ? (
            <div className="flex h-full flex-col items-center justify-center gap-3 py-16 text-center">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-court/15 text-court-light">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" aria-hidden="true">
                  <path d="M4 11.5L9 16.5L18 6.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </span>
              <h3 className="text-base font-semibold text-ink">You're on the list</h3>
              <p className="max-w-xs text-sm text-ink/60">
                We'll reach out as soon as we have news — see you at 2500 Heritage.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-5">
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Full name" htmlFor="name">
                  <input id="name" name="name" type="text" required className={inputClasses} placeholder="Juan Dela Cruz" />
                </Field>
                <Field label="Mobile number" htmlFor="phone">
                  <input id="phone" name="phone" type="tel" required className={inputClasses} placeholder="0917 000 0000" />
                </Field>
              </div>

              <Field label="Email" htmlFor="email">
                <input id="email" name="email" type="email" className={inputClasses} placeholder="you@email.com" />
              </Field>

              <Field label="Which sport interests you most?" htmlFor="sport">
                <select id="sport" name="sport" className={inputClasses} defaultValue="any">
                  <option value="any">Not sure yet</option>
                  <option value="pickleball">Pickleball</option>
                  <option value="badminton">Badminton</option>
                  <option value="taekwondo">Taekwondo</option>
                  <option value="all">All three</option>
                </select>
              </Field>

              <Field label="Notes (optional)" htmlFor="notes">
                <textarea
                  id="notes"
                  name="notes"
                  rows={3}
                  className={`${inputClasses} resize-none`}
                  placeholder="Questions, group size, anything we should know"
                />
              </Field>

              <Button type="submit" variant="primary" className="mt-2">
                Notify me when doors open
              </Button>
            </form>
          )}
        </div>
      </Container>
    </section>
  )
}

const inputClasses =
  'w-full rounded-xl border border-ink/15 bg-sand-dim px-4 py-3 text-sm text-ink placeholder:text-ink/35 outline-none transition-all duration-200 focus:border-court focus:bg-white focus:ring-4 focus:ring-court/15'

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string
  htmlFor: string
  children: ReactNode
}) {
  return (
    <label htmlFor={htmlFor} className="flex flex-col gap-2 text-sm font-medium text-ink/80">
      {label}
      {children}
    </label>
  )
}

function IconPin() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" className="mt-0.5 shrink-0 text-court-light" aria-hidden="true">
      <path
        d="M10 18s6-5.6 6-10.4A6 6 0 0 0 4 7.6C4 12.4 10 18 10 18Z"
        stroke="currentColor"
        strokeWidth="1.7"
      />
      <circle cx="10" cy="7.6" r="2.2" stroke="currentColor" strokeWidth="1.7" />
    </svg>
  )
}

function IconPhone() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" className="mt-0.5 shrink-0 text-court-light" aria-hidden="true">
      <path
        d="M4 3h3l1.5 4-2 1.5a10 10 0 0 0 5 5l1.5-2 4 1.5v3a1.5 1.5 0 0 1-1.6 1.5C9.5 17 3 10.5 2.5 4.6A1.5 1.5 0 0 1 4 3Z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function IconClock() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" className="mt-0.5 shrink-0 text-court-light" aria-hidden="true">
      <circle cx="10" cy="10" r="7.3" stroke="currentColor" strokeWidth="1.6" />
      <path d="M10 6v4.3l3 2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
